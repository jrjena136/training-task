package com.springannotations.controller;


import org.springframework.stereotype.Controller;

@Controller
public class HelloController {

}
